const mongoose = require("mongoose");

const userSchema = new mongoose.Schema(
  {
    username: { type: String, required: true },
    email: { type: String, required: true, unique: true },
    password: { type: String, required: true }, // later store hashed password
  },
  { timestamps: true }
);

module.exports = mongoose.model("User", userSchema);